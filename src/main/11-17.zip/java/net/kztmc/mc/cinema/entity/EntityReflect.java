package net.kztmc.mc.cinema.entity;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;

import net.kztmc.mc.cinema.Cinema;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.world.entity.Entity;

/**
 * 非公開・名前が不確かなフィールドやメソッドへの書き込み。
 * 失敗はログを1回だけ出して、以降は何もしない。フィールドが見つからないときは、
 * 同じ型のフィールドの一覧もログに出す(正しい名前を探す手がかりにする)。
 */
public final class EntityReflect {
    private EntityReflect() {}

    private static final Map<String, Field> FIELDS = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();
    private static final Map<String, List<Field>> MATCHED = new HashMap<>();
    private static final Set<Class<?>> DUMPED = new HashSet<>();

    @FunctionalInterface
    private interface Setter {
        void set(Field f) throws IllegalAccessException;
    }

    public static boolean setInt(Object target, String name, int value) {
        return set(target, name, int.class, f -> f.setInt(target, value));
    }

    public static boolean setFloat(Object target, String name, float value) {
        return set(target, name, float.class, f -> f.setFloat(target, value));
    }

    /** 名前の候補を順に試して、最初に見つかったフィールドに書き込む。全部見つからなければ、ログに候補の一覧を出す */
    public static boolean trySetFloat(Object target, float value, String... names) {
        String groupKey = target.getClass().getName() + "#" + String.join("|", names);
        if (FAILED.contains(groupKey)) return false;
        for (String name : names) {
            try {
                String key = target.getClass().getName() + "#" + name;
                field(target.getClass(), name, key).setFloat(target, value);
                return true;
            } catch (NoSuchFieldException ignored) {
                // 次の候補へ
            } catch (ReflectiveOperationException | RuntimeException ex) {
                FAILED.add(groupKey);
                Cinema.LOGGER.warn("Could not set field '{}' on {}", name, target.getClass().getName(), ex);
                return false;
            }
        }
        FAILED.add(groupKey);
        Cinema.LOGGER.warn("None of the fields {} were found on {}. float fields there: {}",
                List.of(names), target.getClass().getName(), candidates(target.getClass(), float.class));
        return false;
    }

    private static boolean set(Object target, String name, Class<?> type, Setter setter) {
        String key = target.getClass().getName() + "#" + name;
        if (FAILED.contains(key)) return false;
        try {
            setter.set(field(target.getClass(), name, key));
            return true;
        } catch (NoSuchFieldException ex) {
            FAILED.add(key);
            Cinema.LOGGER.warn("Field '{}' not found on {}. {} fields there: {}",
                    name, target.getClass().getName(), type.getSimpleName(), candidates(target.getClass(), type));
            return false;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            FAILED.add(key);
            Cinema.LOGGER.warn("Could not set field '{}' on {}", name, target.getClass().getName(), ex);
            return false;
        }
    }

    /** 公開メソッドの呼び出し(クラスを直接参照せずに済ませる)。失敗したらログを1回出して、以降は何もしない */
    public static void invoke(Object target, String name, Class<?>[] types, Object... args) {
        String key = target.getClass().getName() + "#" + name + "()";
        if (FAILED.contains(key)) return;
        try {
            Method m = target.getClass().getMethod(name, types);
            m.invoke(target, args);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            FAILED.add(key);
            Cinema.LOGGER.warn("Could not call method '{}' on {}", name, target.getClass().getName(), ex);
        }
    }

    /** 親クラスもたどってフィールドを探す(エルダーガーディアンは Guardian を継承している等) */
    private static Field field(Class<?> start, String name, String key) throws NoSuchFieldException {
        Field cached = FIELDS.get(key);
        if (cached != null) return cached;

        Class<?> c = start;
        while (true) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                FIELDS.put(key, f);
                return f;
            } catch (NoSuchFieldException ex) {
                c = c.getSuperclass();
                if (c == null) throw ex;
            }
        }
    }

    /** 診断用: 指定した型の、static でないフィールドの一覧("宣言クラス.名前") */
    private static List<String> candidates(Class<?> start, Class<?> type) {
        List<String> out = new ArrayList<>();
        for (Class<?> c = start; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (f.getType() == type && !Modifier.isStatic(f.getModifiers())) {
                    out.add(c.getSimpleName() + "." + f.getName());
                }
            }
        }
        return out;
    }
    public static boolean setFloatsMatching(Object target, float value, List<String> anyOfA, List<String> anyOfB) {
        Class<?> cls = target.getClass();
        String key = cls.getName() + "#match" + anyOfA + anyOfB;

        List<Field> fields = MATCHED.get(key);
        if (fields == null) {
            fields = new ArrayList<>();
            for (Class<?> c = cls; c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (f.getType() != float.class || Modifier.isStatic(f.getModifiers())) continue;
                    String n = f.getName().toLowerCase(Locale.ROOT);
                    if (containsAny(n, anyOfA) && containsAny(n, anyOfB)) {
                        try {
                            f.setAccessible(true);
                            fields.add(f);
                        } catch (RuntimeException ex) {
                            Cinema.LOGGER.warn("Cannot access field {}", f, ex);
                        }
                    }
                }
            }
            MATCHED.put(key, fields);

            if (fields.isEmpty()) {
                Cinema.LOGGER.warn("[Cinema] no float field matched {} x {} on {}. Related fields: {}",
                        anyOfA, anyOfB, cls.getName(), related(cls, anyOfA));
            } else {
                List<String> names = new ArrayList<>();
                for (Field f : fields) names.add(f.getDeclaringClass().getSimpleName() + "." + f.getName());
                Cinema.LOGGER.info("[Cinema] writing {} on {}: {}", anyOfA, cls.getSimpleName(), names);
            }
        }

        for (Field f : fields) {
            try {
                f.setFloat(target, value);
            } catch (IllegalAccessException | RuntimeException ignored) {
                // 次回以降も同じ失敗になるので、ここでは何もしない
            }
        }
        return !fields.isEmpty();
    }

    private static boolean containsAny(String lowerName, List<String> keywords) {
        for (String k : keywords) {
            if (lowerName.contains(k.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    /** 診断用: キーワードのどれかを名前に含む、あらゆる型のフィールドの一覧("宣言クラス.名前(型)") */
    private static List<String> related(Class<?> start, List<String> keywords) {
        List<String> out = new ArrayList<>();
        for (Class<?> c = start; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (containsAny(f.getName().toLowerCase(Locale.ROOT), keywords)) {
                    out.add(c.getSimpleName() + "." + f.getName() + "(" + f.getType().getSimpleName() + ")");
                }
            }
        }
        return out;
    }

    public static Object getObject(Object target, String name) {
        String key = target.getClass().getName() + "#" + name;
        String getKey = key + "#get";
        if (FAILED.contains(getKey)) return null;
        try {
            return field(target.getClass(), name, key).get(target);
        } catch (NoSuchFieldException ex) {
            FAILED.add(getKey);
            Cinema.LOGGER.warn("[Cinema] field '{}' not found on {}", name, target.getClass().getName());
            return null;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            FAILED.add(getKey);
            Cinema.LOGGER.warn("[Cinema] could not read field '{}' on {}", name, target.getClass().getName(), ex);
            return null;
        }
    }

    public static boolean setBoolean(Object target, String name, boolean value) {
        return set(target, name, boolean.class, f -> f.setBoolean(target, value));
    }

    /** 診断用: 全フィールドの名前・型・現在値を、クラスごとに1回だけログに出す */
    public static void dumpOnce(Object target) {
        Class<?> cls = target.getClass();
        if (!DUMPED.add(cls)) return;
        List<String> out = new ArrayList<>();
        for (Class<?> c = cls; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                String v;
                try {
                    f.setAccessible(true);
                    v = String.valueOf(f.get(target));
                } catch (ReflectiveOperationException | RuntimeException ex) {
                    v = "?";
                }
                out.add(c.getSimpleName() + "." + f.getName() + "(" + f.getType().getSimpleName() + ")=" + v);
            }
        }
        Cinema.LOGGER.warn("[Cinema] fields of {}: {}", cls.getName(), out);
    }

    /** オブジェクト型のフィールドへの書き込み(null も可) */
    public static boolean setObject(Object target, String name, Object value) {
        return set(target, name, Object.class, f -> f.set(target, value));
    }

    private static final Set<String> STOP = Set.of(
            "net.minecraft.world.entity.LivingEntity", "net.minecraft.world.entity.Mob",
            "net.minecraft.world.entity.Entity", "java.lang.Object");

    private static void warnOnce(String key, String message, Object... args) {
        if (FAILED.add(key)) Cinema.LOGGER.warn(message, args);
    }

    /** int フィールドの値。見つからなければ fallback(ログは出さない) */
    public static int getIntQuiet(Object target, String name, int fallback) {
        try {
            return field(target.getClass(), name, target.getClass().getName() + "#" + name).getInt(target);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return fallback;
        }
    }

    /** long フィールドへの書き込み。版によって型や名前が違うので、見つからなくてもログは出さない */
    public static boolean setLongQuiet(Object target, String name, long value) {
        try {
            field(target.getClass(), name, target.getClass().getName() + "#" + name).setLong(target, value);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return false;
        }
    }

    /** 名前の候補を順に試して、最初に見つかった boolean フィールドに書き込む。全部無ければ警告を1回出す */
    public static boolean setBooleanFirst(Object target, boolean value, String... names) {
        for (String name : names) {
            try {
                field(target.getClass(), name, target.getClass().getName() + "#" + name).setBoolean(target, value);
                return true;
            } catch (NoSuchFieldException ignored) {
                // 次の候補へ
            } catch (ReflectiveOperationException | RuntimeException ex) {
                warnOnce(target.getClass().getName() + "#bool:" + name, "[Cinema] could not write '{}'", name, ex);
                return false;
            }
        }
        warnOnce(target.getClass().getName() + "#bool:" + List.of(names),
                "[Cinema] none of the boolean fields {} were found on {}", List.of(names), target.getClass().getName());
        return false;
    }

    /** 名前の候補を順に試して、最初に見つかったメソッドを呼ぶ(非公開でもよい)。全部無ければ、候補の一覧つきで警告を1回出す */
    public static boolean invokeFirst(Object target, List<String> names, Object... args) {
        for (String name : names) {
            Boolean r = tryInvoke(target, name, args);
            if (r != null) return r;
        }
        warnOnce(target.getClass().getName() + "#none:" + names,
                "[Cinema] none of the methods {} were found on {}. Declared methods there: {}",
                names, target.getClass().getName(), methodNames(target.getClass()));
        return false;
    }

    /** 引数が enum のメソッドを、定数名で呼ぶ(enum のクラスを直接参照しなくて済む) */
    public static boolean invokeWithEnumArg(Object target, String name, String constantName) {
        for (Class<?> c = target.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != 1 || !m.getParameterTypes()[0].isEnum()) continue;
                for (Object k : m.getParameterTypes()[0].getEnumConstants()) {
                    if (((Enum<?>) k).name().equals(constantName)) {
                        try {
                            m.setAccessible(true);
                            m.invoke(target, k);
                            return true;
                        } catch (ReflectiveOperationException | RuntimeException ex) {
                            warnOnce(target.getClass().getName() + "#enum:" + name, "[Cinema] call to {} failed", name, ex);
                            return false;
                        }
                    }
                }
            }
        }
        warnOnce(target.getClass().getName() + "#enum:" + name + constantName,
                "[Cinema] method {}({}) was not found on {}", name, constantName, target.getClass().getName());
        return false;
    }

    /** 診断用(/cinema fields): LivingEntity より下のクラスの、全フィールド(現在値つき)とメソッドをログに出す */
    public static void dumpEntity(Object e) {
        Cinema.LOGGER.info("[Cinema] ===== {} =====", e.getClass().getName());
        for (Class<?> c = e.getClass(); c != null && !STOP.contains(c.getName()); c = c.getSuperclass()) {
            List<String> fields = new ArrayList<>();
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                String v;
                try {
                    f.setAccessible(true);
                    v = String.valueOf(f.get(e));
                } catch (ReflectiveOperationException | RuntimeException ex) {
                    v = "?";
                }
                fields.add(f.getName() + "(" + f.getType().getSimpleName() + ")=" + v);
            }
            List<String> methods = new ArrayList<>();
            for (Method m : c.getDeclaredMethods()) {
                if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()) {
                    methods.add(m.getName() + "/" + m.getParameterCount());
                }
            }
            Cinema.LOGGER.info("[Cinema] {} fields: {}", c.getSimpleName(), fields);
            Cinema.LOGGER.info("[Cinema] {} methods: {}", c.getSimpleName(), methods);
        }
    }

    /** 見つかって呼べたら TRUE、見つかったが失敗したら FALSE、見つからなければ null */
    /** 見つかって呼べたら TRUE、見つかったが失敗したら FALSE、見つからなければ null */
    private static Boolean tryInvoke(Object target, String name, Object[] args) {
        for (Class<?> c = target.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
                Object[] converted = coerce(m.getParameterTypes(), args);
                if (converted == null) continue;
                try {
                    m.setAccessible(true);
                    m.invoke(target, converted);
                    return Boolean.TRUE;
                } catch (ReflectiveOperationException | RuntimeException ex) {
                    warnOnce(target.getClass().getName() + "#call:" + name,
                            "[Cinema] call to {} failed on {}", name, target.getClass().getName(), ex);
                    return Boolean.FALSE;
                }
            }
        }
        return null;
    }

    /** 引数を、メソッドの引数の型に合わせる。数値は、int / long / float / double の間で変換する。合わなければ null */
    private static Object[] coerce(Class<?>[] types, Object[] args) {
        Object[] out = new Object[args.length];
        for (int i = 0; i < types.length; i++) {
            Object a = args[i];
            Class<?> w = wrap(types[i]);
            if (a == null) {
                if (types[i].isPrimitive()) return null;
            } else if (w.isInstance(a)) {
                out[i] = a;
            } else if (a instanceof Number n && w == Long.class) {
                out[i] = n.longValue();
            } else if (a instanceof Number n && w == Integer.class) {
                out[i] = n.intValue();
            } else if (a instanceof Number n && w == Float.class) {
                out[i] = n.floatValue();
            } else if (a instanceof Number n && w == Double.class) {
                out[i] = n.doubleValue();
            } else {
                return null;
            }
        }
        return out;
    }

    /** 警告を出さずに、見つかったメソッドを呼ぶ。呼べたら true */
    public static boolean invokeQuiet(Object target, List<String> names, Object... args) {
        for (String name : names) {
            Boolean r = tryInvoke(target, name, args);
            if (Boolean.TRUE.equals(r)) return true;
        }
        return false;
    }

    private static Class<?> wrap(Class<?> t) {
        if (!t.isPrimitive()) return t;
        if (t == boolean.class) return Boolean.class;
        if (t == int.class) return Integer.class;
        if (t == float.class) return Float.class;
        if (t == double.class) return Double.class;
        if (t == long.class) return Long.class;
        if (t == byte.class) return Byte.class;
        if (t == short.class) return Short.class;
        return Character.class;
    }

    private static List<String> methodNames(Class<?> start) {
        List<String> out = new ArrayList<>();
        for (Class<?> c = start; c != null && !STOP.contains(c.getName()); c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()) {
                    out.add(c.getSimpleName() + "." + m.getName() + "/" + m.getParameterCount());
                }
            }
        }
        return out;
    }

    /** 引数がすべて enum のメソッドを、定数名で呼ぶ(馬の setVariantAndMarkings など) */
    public static boolean invokeWithEnumArgs(Object target, String name, String... constantNames) {
        for (Class<?> c = target.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != constantNames.length) continue;
                Class<?>[] types = m.getParameterTypes();
                Object[] args = new Object[types.length];
                boolean ok = true;
                for (int i = 0; i < types.length && ok; i++) {
                    Object found = null;
                    if (types[i].isEnum()) {
                        for (Object k : types[i].getEnumConstants()) {
                            if (((Enum<?>) k).name().equals(constantNames[i])) found = k;
                        }
                    }
                    args[i] = found;
                    ok = found != null;
                }
                if (!ok) continue;
                try {
                    m.setAccessible(true);
                    m.invoke(target, args);
                    return true;
                } catch (ReflectiveOperationException | RuntimeException ex) {
                    warnOnce(target.getClass().getName() + "#enums:" + name, "[Cinema] call to {} failed", name, ex);
                    return false;
                }
            }
        }
        warnOnce(target.getClass().getName() + "#enums:" + name + List.of(constantNames),
                "[Cinema] method {}({}) was not found on {}", name, List.of(constantNames), target.getClass().getName());
        return false;
    }

    /**
     * エンティティの同期データ(EntityDataAccessor。帯電クリーパーなど)に、値を書き込む。
     * @param accessorField データの識別子を持つ static フィールドの名前(例: DATA_IS_POWERED)
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static boolean setSyncedData(Entity e, String accessorField, Object value) {
        String key = e.getClass().getName() + "#data:" + accessorField;
        if (FAILED.contains(key)) return false;
        try {
            Field f = null;
            for (Class<?> c = e.getClass(); c != null && f == null; c = c.getSuperclass()) {
                try {
                    f = c.getDeclaredField(accessorField);
                } catch (NoSuchFieldException ignored) {
                    // 親クラスも探す
                }
            }
            if (f == null) throw new NoSuchFieldException(accessorField);
            f.setAccessible(true);
            e.getEntityData().set((EntityDataAccessor) f.get(null), value);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            FAILED.add(key);
            Cinema.LOGGER.warn("[Cinema] could not write synced data '{}' on {}", accessorField, e.getClass().getName(), ex);
            return false;
        }
    }

    /** target のクラスから stop(含まない)までの間に、その名前のメソッドを宣言しているクラスがあるか。Mob の空の setBaby と区別する */
    public static boolean hasMethodBefore(Object target, String name, Class<?> stop) {
        for (Class<?> c = target.getClass(); c != null && c != stop && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().equals(name)) return true;
            }
        }
        return false;
    }

    /** float フィールドの値。見つからなければ fallback(ログは出さない) */
    public static float getFloatQuiet(Object target, String name, float fallback) {
        try {
            return field(target.getClass(), name, target.getClass().getName() + "#" + name).getFloat(target);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return fallback;
        }
    }

    /** メソッドを呼んで、戻り値を返す(見つからない・失敗したときは null)。ログは出さない */
    public static Object call(Object target, String name, Object... args) {
        for (Class<?> c = target.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
                Object[] converted = coerce(m.getParameterTypes(), args);
                if (converted == null) continue;
                try {
                    m.setAccessible(true);
                    return m.invoke(target, converted);
                } catch (ReflectiveOperationException | RuntimeException ex) {
                    return null;
                }
            }
        }
        return null;
    }

    /** 診断用: オブジェクトのクラスの、全フィールドとメソッドを、Object の手前までログに出す */
    public static void dumpObject(Object o) {
        Cinema.LOGGER.info("[Cinema] ===== {} =====", o.getClass().getName());
        for (Class<?> c = o.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            List<String> fields = new ArrayList<>();
            for (Field f : c.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers())) fields.add(f.getName() + "(" + f.getType().getSimpleName() + ")");
            }
            List<String> methods = new ArrayList<>();
            for (Method m : c.getDeclaredMethods()) {
                if (!m.isSynthetic()) methods.add(m.getName() + "/" + m.getParameterCount());
            }
            Cinema.LOGGER.info("[Cinema] {} fields: {}", c.getSimpleName(), fields);
            Cinema.LOGGER.info("[Cinema] {} methods: {}", c.getSimpleName(), methods);
        }
    }

    /** オブジェクトのフィールドの値。見つからなければ null(警告は出さない) */
    public static Object getObjectQuiet(Object target, String name) {
        try {
            return field(target.getClass(), name, target.getClass().getName() + "#" + name).get(target);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }

    /** double フィールドへの書き込み(マントの位置の記録など) */
    public static boolean setDouble(Object target, String name, double value) {
        try {
            field(target.getClass(), name, target.getClass().getName() + "#" + name).setDouble(target, value);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            warnOnce(target.getClass().getName() + "#d:" + name, "[Cinema] could not write double '{}' on {}",
                    name, target.getClass().getName());
            return false;
        }
    }

    /** int フィールドへの書き込み。見つからなければ false(警告は出さない) */
    public static boolean setIntQuiet(Object target, String name, int value) {
        try {
            field(target.getClass(), name, target.getClass().getName() + "#" + name).setInt(target, value);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return false;
        }
    }

    /** 診断用: 名前に、キーワードのどれかを含む、フィールドとメソッドだけを、ログに出す */
    public static void dumpMatching(Object target, String... keywords) {
        Cinema.LOGGER.info("[Cinema] ===== {} (matching {}) =====", target.getClass().getName(), List.of(keywords));
        for (Class<?> c = target.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            List<String> found = new ArrayList<>();
            for (Field f : c.getDeclaredFields()) {
                if (matches(f.getName(), keywords)) found.add("field " + f.getName() + "(" + f.getType().getSimpleName() + ")");
            }
            for (Method m : c.getDeclaredMethods()) {
                if (!m.isSynthetic() && matches(m.getName(), keywords)) found.add(m.getName() + "/" + m.getParameterCount());
            }
            if (!found.isEmpty()) Cinema.LOGGER.info("[Cinema] {}: {}", c.getSimpleName(), found);
        }
    }

    private static boolean matches(String name, String[] keywords) {
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        for (String k : keywords) {
            if (lower.contains(k.toLowerCase(java.util.Locale.ROOT))) return true;
        }
        return false;
    }
}